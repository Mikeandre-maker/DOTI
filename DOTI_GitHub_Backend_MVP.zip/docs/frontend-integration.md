
# DOTI frontend integration checklist

1. Use Supabase JS with the project's publishable key.
2. Keep the service-role/secret key out of the browser.
3. Request GPS only after the user taps "Use my location".
4. Send latitude/longitude with pickup_requests.
5. Use `supabase.functions.invoke("create-payment-intent")` for payment initiation.
6. Do not mark a payment Paid from the frontend. Only a verified provider webhook should do that.
7. Use Edge Functions for provider credentials and webhooks.
