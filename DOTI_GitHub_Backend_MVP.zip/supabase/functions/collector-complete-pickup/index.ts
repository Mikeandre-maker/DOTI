
import { createClient } from "npm:@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", {status:405});

  const url = Deno.env.get("SUPABASE_URL")!;
  const key = Deno.env.get("SUPABASE_ANON_KEY")!;
  const supabase = createClient(url, key, {
    global: {headers:{Authorization:req.headers.get("Authorization") ?? ""}}
  });

  const {data:{user}} = await supabase.auth.getUser();
  if (!user) return Response.json({error:"Unauthorized"},{status:401});

  const {pickup_id} = await req.json();
  if (!pickup_id) return Response.json({error:"pickup_id required"},{status:400});

  const {data,error} = await supabase
    .from("pickup_requests")
    .update({status:"Completed", completed_at:new Date().toISOString()})
    .eq("id",pickup_id)
    .eq("collector_id",user.id)
    .select("id,status,completed_at")
    .single();

  if(error) return Response.json({error:error.message},{status:400});
  return Response.json({pickup:data});
});
