
import { createClient } from "npm:@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", {status:405});

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
  const supabase = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } }
  });

  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) return Response.json({error:"Unauthorized"}, {status:401});

  const body = await req.json();
  const { service, method, account_reference, amount_zmw } = body;

  if (!service || !method || !account_reference || !amount_zmw || Number(amount_zmw) <= 0) {
    return Response.json({error:"Invalid payment request"}, {status:400});
  }

  // This creates the internal payment intent.
  // The actual MTN/Airtel/Zamtel API call belongs here after merchant credentials
  // are supplied as Supabase secrets. Never put those secrets in the browser.
  const { data, error } = await supabase
    .from("payment_intents")
    .insert({
      user_id: user.id,
      service,
      method,
      account_reference,
      amount_zmw: Number(amount_zmw),
      status: "Pending"
    })
    .select("id,service,method,amount_zmw,status,created_at")
    .single();

  if (error) return Response.json({error:error.message}, {status:500});

  return Response.json({
    payment_intent: data,
    next_step: "Connect the selected Zambian payment provider in this Edge Function."
  });
});
